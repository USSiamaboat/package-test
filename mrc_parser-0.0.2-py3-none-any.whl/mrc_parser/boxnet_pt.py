import torch

import numpy as np
from numpy.typing import NDArray

from typing import List, Self

from .config import *
from .boxnet import Boxnet

class BoxnetPT(Boxnet):
    """
    Wrapper for PyTorch Boxnet v2

    Args:
        model_path: path to the .pt file (must contain entire model, not just weights)
    """


    def __init__(self, model_path: str):
        self.model = torch.load(model_path, weights_only=False)
        self.model.eval()

        self.device = "cpu"


    def to(self, device) -> Self:
        """
        Sets the intended device of this model and its inputs

        Args:
            device: the device to move to ("cuda", "mps", etc.)
        """

        self.device = device

        self.model.to(self.device)

        return self


    def make_batches(self, imgs: List[NDArray], batch_size: int) -> List[NDArray]:
        """
        Batches a list of images

        Args:
            imgs: list of images
            batch_size: exact batch size
        """

        imgs = [x.reshape((256, 256, 1)) for x in imgs]

        result = []

        for i in range(0, len(imgs), batch_size):
            result.append(np.stack(imgs[i:min(len(imgs), i+batch_size)]))
        
        return result
    

    def compute_batch(self, imgs: NDArray) -> List[NDArray]:
        """
        Processes a batch of 256x256 images with Boxnet v2 and returns
        a list of images for probabilities for each class each with
        shape (height, width, 3)

        Args:
            imgs: list of images
        """

        inputs = torch.tensor(imgs, dtype=torch.float32)
        inputs = inputs.to(self.device)

        outputs = None
        
        outputs = self.model(inputs).detach().cpu().numpy()
        
        batch_size = outputs.shape[0]
        
        outputs = outputs.reshape(batch_size, 256, 256, 3)

        return [output for output in outputs]


    def __call__(self, imgs: List[NDArray], max_batch_size: int = 24) -> List[NDArray]:
        """
        Processes a list of 256x256 images with Boxnet v2 and returns
        a list of images for probabilities for each class each with
        shape (height, width, 3)

        Args:
            imgs: list of images
            max_batch_size: max batch size
        """

        outputs = []

        self.model.eval()
        with torch.inference_mode():
            for batch in self.make_batches(imgs, max_batch_size):
                outputs += self.compute_batch(batch)
        
        return outputs


if __name__ == "__main__":
    # Example usage

    from .util import * # Not strictly necessary, but helpful for pre and post processing

    model = BoxnetPT("boxnet.pt") # Default initialize model

    # Generate tiles
    img = np.random.rand(2048, 2048)
    coords, tiles = tile_with_overlap(img)

    # Run model on tiles
    processed_tiles = model(tiles)

    # Recombine tiles into an image
    processed_img = recombine(processed_tiles, coords)

