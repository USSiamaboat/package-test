import numpy as np

import mrcfile

from skimage.transform import resize

from typing import Tuple
from numpy.typing import NDArray

from .boxnet import Boxnet
from .util import *


class MRC_Parser:
    """
    Preprocessing and Boxnet instance to contain the entire
    pipeline from .mrc to masks and particle picking

    Args:
        model: instance of a model that takes tiles
    """


    def __init__(self, model: Boxnet):
        self.model = model


    def rescale(self, img: NDArray, resolution: Tuple[int, int]) -> NDArray:
        """
        Downscales the image by approximately the given factor

        Args:
            img: the image (2D image)
            ideal_factor: the desired scaling factor
        """

        return resize(
            img,
            resolution,
            anti_aliasing=True,
            preserve_range=True
        )


    def __call__(self, path: str) -> NDArray:
        """
        Runs Boxnet v2 on an unprocessed .mrc image
        
        Args:
            path: string path to the .mrc file
        """

        # Load and preprocess
        img = None
        resolution = None

        with mrcfile.open(path, permissive=True) as f:
            # Load data
            temp = np.array(f.data)
            
            # Standardize (mean 0, sd 1)
            img = (temp - temp.mean())/temp.std()

            # Record resolution
            resolution = f.voxel_size.x

        # Downscale to Boxnet's desired resolution
        factor = 8/resolution
        downscaled_img = self.rescale(img, (img.shape[0] // factor, img.shape[1] // factor))

        # Generate tiles
        coords, tiles = tile_with_overlap(downscaled_img)

        # Pass through network
        new_tiles = self.model(tiles)

        # Recombine tiles into image
        new_img = recombine(new_tiles, coords)

        # Upscale to original resolution
        return self.rescale(new_img, img.shape)


if __name__ == "__main__":
    # Example usage

    from boxnet_tf import BoxnetTF
    import matplotlib.pyplot as plt

    # Provide an image path
    img_path = "example.mrc"

    # Load model (provides the option for loading torch port or other models)
    model = BoxnetTF()

    # Init parser
    parser = MRC_Parser(model)

    # Everything else in one line
    result = parser(img_path)

