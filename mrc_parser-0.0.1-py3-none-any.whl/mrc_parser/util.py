import mrcfile

import numpy as np
from numpy.typing import NDArray

from typing import List, Tuple

from .config import *


def mrc_to_numpy(path: str) -> NDArray:
    """
    Converts an image available at a particular

    Args:
        path: the path to the .mrc file
    """

    img = None

    with mrcfile.open(path, permissive=True) as f:
        img = np.array(f.data)
    
    return img


def tile_with_overlap(img: NDArray) -> Tuple[List[Tuple[int, int]], List[NDArray]]:
    """
    Given an image, return a list of tiles and indices in
    the format Tuple(List[Tuple(top left i, top left j)], List[NDArray[TILE_SIZE, TILE_SIZE]])

    Args:
        img: the image to tile
    """

    stride = TILE_SIZE - TILE_OVERLAP
    h, w = img.shape
    tiles = []
    coords = []

    img = img.astype(np.float32)

    row_starts = list(range(0, h - TILE_SIZE + 1, stride))
    col_starts = list(range(0, w - TILE_SIZE + 1, stride))

    # Guarantee bottom edge
    if row_starts[-1] != h - TILE_SIZE:
        row_starts.append(h - TILE_SIZE)

    # Guarantee right edge
    if col_starts[-1] != w - TILE_SIZE:
        col_starts.append(w - TILE_SIZE)

    for i in row_starts:
        for j in col_starts:
            tiles.append(img[i:(i+TILE_SIZE), j:(j+TILE_SIZE)])
            coords.append((i, j))

    return coords, tiles


def recombine(tiles: List[NDArray], coords: List[Tuple]) -> NDArray:
    """
    Recombines processed image tiles into a large image using the
    mean to resolve overlaps

    Args:
        tiles: a list of tiles in the shape List[NDArray[TILE_SIZE, TILE_SIZE, 3]]
        coords: a list of top left coordinate tuples in the shape List[Tuple(i, j)]
    """
    
    assert len(tiles) == len(coords), f"Tile and coord count mismatch: {len(tiles)} != {len(coords)}"

    height = max([coord[0] for coord in coords]) + TILE_SIZE
    width = max([coord[1] for coord in coords]) + TILE_SIZE
    shape = (height, width, 3)

    sums = np.zeros(shape)
    counts = np.zeros(shape)

    for i in range(len(tiles)):
        j, k = coords[i]
        sums[j:(j+TILE_SIZE), k:(k+TILE_SIZE), :] += tiles[i]
        counts[j:(j+TILE_SIZE), k:(k+TILE_SIZE), :] += np.ones((TILE_SIZE, TILE_SIZE, 3))
    
    return sums / counts

