from numpy.typing import NDArray
from typing import List

class Boxnet:
    """
    This is an abstraction to define a general interface
    for models that perform Boxnet functions

    Args:
        model_path: path to the necessary file(s)
    """

    
    def __init__(self, model_path: str):
        pass


    def __call__(self, imgs: List[NDArray], max_batch_size: int = 24) -> List[NDArray]:
        """
        Processes a list of 256x256 images with Boxnet v2 and returns
        a list of images for probabilities for each class each with
        shape (height, width, 3)

        Args:
            imgs: list of images
            max_batch_size: max batch size
        """

        return []
