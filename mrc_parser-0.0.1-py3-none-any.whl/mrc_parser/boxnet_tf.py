from tqdm import tqdm

from ai_edge_litert.interpreter import Interpreter

import numpy as np
from numpy.typing import NDArray

from typing import List

from .config import *
from .boxnet import Boxnet

class BoxnetTF(Boxnet):
    """
    Wrapper for TensorFlow Lite Boxnet v2

    Args:
        model_path: path to the .tflite file (default boxnet.tflite)
    """


    def __init__(self, model_path: str = "boxnet.tflite"):
        self.interpreter = Interpreter(model_path=model_path)
        self.interpreter.allocate_tensors()

        # Get input and output tensor details
        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()

        # Set dummy data
        training_learning_rate = np.array([0.0], dtype=np.float32)
        image_classes = np.zeros((1, 256, 256, 3)).astype(np.float32)
        image_weights = np.zeros((1, 256, 256, 1)).astype(np.float32)
        images = np.zeros((1, 256, 256, 1)).astype(np.float32)

        self.interpreter.set_tensor(self.input_details[0]['index'], training_learning_rate)
        self.interpreter.set_tensor(self.input_details[1]['index'], image_classes)
        self.interpreter.set_tensor(self.input_details[2]['index'], image_weights)
        self.interpreter.set_tensor(self.input_details[4]['index'], images)


    def make_batches(self, imgs: List[NDArray], batch_size: int) -> List[NDArray]:
        """
        Batches a list of images

        Args:
            imgs: list of images
            batch_size: exact batch size
        """

        imgs = [x.reshape((256, 256, 1)) for x in imgs]

        result = []

        for i in range(0, len(imgs), batch_size):
            result.append(np.stack(imgs[i:min(len(imgs), i+batch_size)]))
        
        return result
    

    def compute_batch(self, imgs: NDArray) -> List[NDArray]:
        """
        Processes a batch of 256x256 images with Boxnet v2 and returns
        a list of images for probabilities for each class each with
        shape (height, width, 3)

        Args:
            imgs: list of images
        """

        outputs = []

        for i in range(len(imgs)):
            self.interpreter.set_tensor(self.input_details[3]['index'], imgs[i:i+1])
            self.interpreter.invoke()
            outputs.append(self.interpreter.get_tensor(self.output_details[1]['index']))
        
        return [x.reshape(256, 256, 3) for x in outputs]


    def __call__(self, imgs: List[NDArray], max_batch_size: int = 24) -> List[NDArray]:
        """
        Processes a list of 256x256 images with Boxnet v2 and returns
        a list of images for probabilities for each class each with
        shape (height, width, 3)

        Args:
            imgs: list of images
            max_batch_size: max batch size
        """

        outputs = []

        for batch in tqdm(self.make_batches(imgs, max_batch_size)):
            outputs += self.compute_batch(batch)
        
        return outputs


if __name__ == "__main__":
    # Example usage

    from .util import * # Not strictly necessary, but helpful for pre and post processing

    model = BoxnetTF() # Default initialize model

    # Generate tiles
    img = np.random.rand(2048, 2048)
    coords, tiles = tile_with_overlap(img)

    # Run model on tiles
    processed_tiles = model(tiles)

    # Recombine tiles into an image
    processed_img = recombine(processed_tiles, coords)

